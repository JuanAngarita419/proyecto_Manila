import { Component, OnInit, signal, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { ServicioComida } from '../servicios/servicios-comida';
import { ServicioCarrito } from '../servicios/servicios-carrito';
import { Comida as ComidaEntidad } from '../entidades/entidad-comida';

@Component({
  selector: 'app-comida',
  imports: [CommonModule, FormsModule],
  templateUrl: './comida.html',
  styleUrl: './comida.css',
})
export class Comida implements OnInit {
  // signal para guardar las comidas, tipado con la entidad ComidaEntidad
  comidas = signal<ComidaEntidad[]>([]);
  cargando = signal(false);
  hayError = signal(false);

  // signal para el plato que se ve en el detalle (null = cerrado)
  platoSeleccionado = signal<ComidaEntidad | null>(null);
  carritoConfirmado = signal(false);
  mostrarBotonSubir = signal(false);

  filtro = 'nombre';
  texto = '';

  constructor(
    private comidaApi: ServicioComida,
    public carrito: ServicioCarrito
  ) {}

  ngOnInit(): void {
    this.buscarTodo();
  }

  // muestra el botón de "volver arriba" cuando el usuario baja suficiente
  @HostListener('window:scroll')
  onScroll() {
    this.mostrarBotonSubir.set(window.scrollY > 400);
  }

  subirArriba() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // pone un precio random a cada plato, entre 10.000 y 45.000
  ponerPrecios(lista: ComidaEntidad[]): ComidaEntidad[] {
    return lista.map((plato) => ({
      ...plato,
      precio: Math.floor(Math.random() * (45000 - 10000 + 1)) + 10000,
    }));
  }

  // trae todas las comidas (letra por letra) o busca por nombre si le paso texto
  buscarTodo(texto: string = '') {
    const peticion = texto
      ? this.comidaApi.buscarPorNombre(texto)
      : this.comidaApi.listarTodas();

    this.cargarResultados(peticion);
  }

  buscar() {
    const texto = this.texto.trim();

    if (!texto) {
      this.buscarTodo();
      return;
    }

    if (this.filtro === 'nombre') {
      this.buscarTodo(texto);
      return;
    }

    this.cargarResultados(this.comidaApi.buscarPorIngrediente(texto));
  }

  private cargarResultados(peticion: Observable<any>): void {
    this.cargando.set(true);
    this.hayError.set(false);

    peticion.subscribe({
      next: (dato: any) => {
        this.comidas.set(this.ponerPrecios(dato.meals ?? []));
        this.cargando.set(false);
      },
      error: (error) => {
        console.error('error API:', error);
        this.hayError.set(true);
        this.cargando.set(false);
      },
    });
  }

  // arma la lista de ingredientes con su medida, ej: "200g Pollo"
  sacarIngredientes(plato: ComidaEntidad): string[] {
    const lista: string[] = [];

    for (let n = 1; n <= 20; n++) {
      const ingrediente = plato['strIngredient' + n];
      const medida = plato['strMeasure' + n];

      if (ingrediente && ingrediente.trim() !== '') {
        lista.push(`${medida ? medida.trim() : ''} ${ingrediente.trim()}`.trim());
      }
    }

    return lista;
  }

  // cuando el plato viene de "buscar por ingrediente" la API no trae todos los datos,
  // entonces si hace falta info, buscamos el detalle completo por nombre
  verDetalle(plato: ComidaEntidad) {
    if (plato.strInstructions) {
      // ya tiene toda la info, solo lo mostramos
      this.platoSeleccionado.set(plato);
      return;
    }

    this.comidaApi.buscarPorNombre(plato.strMeal).subscribe({
      next: (dato: any) => {
        const completo: ComidaEntidad = dato.meals ? dato.meals[0] : plato;
        completo.precio = plato.precio; // mantenemos el mismo precio random
        this.platoSeleccionado.set(completo);
      },
      error: () => {
        this.platoSeleccionado.set(plato);
      },
    });
  }

  cerrarDetalle() {
    this.platoSeleccionado.set(null);
  }

  // manda el plato al carrito de compras
  agregarAlCarrito(plato: ComidaEntidad) {
    this.carrito.agregar({
      id: plato.idMeal,
      nombre: plato.strMeal,
      precio: plato.precio,
      imagen: plato.strMealThumb,
      cantidad: 1,
      tipo: 'comida',
    });

    this.carritoConfirmado.set(true);
    setTimeout(() => this.carritoConfirmado.set(false), 1800);
  }
}